## Resident Evil (GameBoy Color) - Bugfixed Version 1.0 by PacoChan ##
##                                                                  ##
##                        maikelchan88@gmail.com                    ##

----------------------------------------------------------------------

Resident Evil for GameBoy Color was cancelled at 90% of development
and never released. But thanks to a fundraiser, the one that was holding
two builds of this game, released them to the public.

This game has a lot of glitches and you need to do some hacks to be
able to continue at certain areas.

I've fixed the most important issued so the game can be played from
start to finish without hacking. However, there aren't any programmed
endings, so you'll be stuck at the final room and there's nothing it
can be done about it.

Changes made to the game:

- Originally you couldn't access to the Plant 42 room because you
  couldn't use the red book. Now there's no red book. You only have
  to take the white book from the bookcase and the main door to the
  Plant 42 will open (the big door, not the one behind the bookcase
  in the small room).

- The door to the heliporter was opened by default. Now is closed
  like it should be. It will open when you exit the Tyrant room.

- Removed the collision of the left wall in one of the lab's rooms
  to be able to access to the morgue and one of the MO Readers.
  It was impossible to access that room without hacking.
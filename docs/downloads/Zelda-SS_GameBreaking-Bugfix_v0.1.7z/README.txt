#################################################################################
####################### The Legend of Zelda Skyward Sword #######################
#######################     Game-Breaking Bug Fix v0.1    #######################
#######################             BY PACOCHAN           #######################
####################### --------------------------------- #######################
#######################   http://pacochan.tales-tra.com   #######################
#################################################################################

At a certain point toward the end of the Legend of Zelda Skyward Sword,
while collecting pieces of a certain Song, you�re tasked with visiting
the Fire, Water and Thunder Dragons in any order you choose.

If you visit the Thunder Dragon first � and speak to a certain Goron
adventurer more than once � you�ll find that you can no longer trigger
the Fire and Water Dragon events. So you'll have to restart the whole game.

I've been investigating the cause of this glitch and the information Nintendo
gave was correct, but incomplete. This is what happens:

- You can activate the glitch if you choose Lanayru on the first or
  second place. The safest choice is to go to Lanayru after Eldin and Faron.

- The first time you land on Lanayru once the quest of collecting songs has
  started, you'll be able to reach a certain cave from two paths: from Lanayru
  Mine and from West Desert. If you land on Lanayru Mine (I think this is
  only possible on PAL versions of the game, but I'm not sure), you'll see a
  Goron right there. This is the first step to activate the glitch. But if you
  access the cave from West Desert, you'll find that Goron inside the cave and
  you shouldn't worry about getting the glitch.

- When you get the Thunder Dragon's song, the Goron will still be at the place
  you found it the first time. As I said, the game will only break if you speak
  with him at Lanayru Mine. When you speak with him, the game will try to start
  the quest again. But you already have finished it and have the necessary
  objects. So, you cannot do anything at Lanayru, and you cannot any other
  quest because technically you are still doing the Thunder Dragon's quest.
  The game is broken.

- Even if you do Lanayru the last, I don't recommend talking with the Goron
  at Lanayru Mine, because it still changes some events. You'll be able to finish
  the game because you'll already have finished the other song quests. But I
  haven't discovered if it has some minor impact on any event.


So what if you already triggered the glitch? Don't worry. I've made a
Riivolution patch that can fix your save and prevent the glitch from happening
again. You can download Riivolution at http://rvlution.net/wiki/Riivolution
and get some information on how to use it. Once you have downloaded and put
Riivolution on your SD card, you can download my patch here:

http://pacochan.tales-tra.com/index.php/traducciones--romhacks/zelda-skyward-sword-bug-fix

- After that you only have to copy the files to the SD card.
- Run Riivolution with Homebrew Channel or something like that.
- Leave everything as it is and click Launch.
- MAKE A BACKUP OF YOUR SAVE.
- Load your broken save.
- Save immediately after.
- Restart the game as you normally do. You won't need the patch anymore.
- Your save should be fixed.


The patch is compatible with both PAL and NTSC versions of the game. If you have any
problem or question, contact with me.


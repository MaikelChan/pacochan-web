           CHEETAHMEN II - BUGFIXED VERSION 2.1 BY PACOCHAN

                      maikelchan88@gmail.com

-------------------------------------------------------------------------------

This game is infamous because it's one of the worst games ever made.
It's full of all sorts of glitches and it's extremely hard because of
it's glitched gameplay. The game couldn't even be finished.
However, it's a very rare collector's item and can be found for more than $1000.

ApeMan, the boss at the fourth level, disappears if he leaves the screen,
and if you beat him, it also disappears, so you get stuck at that level and
it's impossible to go through the last two levels. Level two boss can
disappear in some circumstances. There's a hacked version of the rom that
offers only the last two levels, but it's also very buggy. The final boss
dissapears too and it's impossible to finish the game.

Now, all of that is fixed and the game can be completed with no problems.
No more enemies disappearing, all levels load correctly, and no annoying
level number glitch (levels 4, 5 and 6 were called level 3).

I made some palette and graphic modifications, to fix some elements that
looked ugly. Also, I fixed some spelling errors in the intro.
         #######################################################
          Resident Evil Remake / Zero Background Extractor v0.1
                               By PacoChan
                      http://pacochan.tales-tra.com
         #######################################################


This program can find and extract the room backgrounds from Resident Evil
Remake and Resident Evil Zero. It's not perfect and some of the extracted
images will be corrupted. The program can't insert the images back. It's
just for taking a look at those backgrounds :P

The program also works with trial and beta versions of the mentioned games,
so you'll be able to find some interesting stuff, like beta unfinished
levels.


################################ HOW TO USE ###############################

- Press "Extract Background(s)..." to select one or more files to extract.
  Resident Evil Remake stores the backgrounds in *.bgz files found inside
  the folders "st1\", "st2\", "st3\", "st4\", "st5\". Resident Evil Zero's
  backgrounds can be found in *.mhp files inside the folder "bio0\bg\".
  
- In order to see the extracted images with any image viewer, they need to
  be fixed. The program usually detects which images need to be fixed,
  but sometimes it doesn't. So some images will be corrupted.
  In that case, you can try selecting those *.jpg files by presing the
  "Fix JPG(s)..." button. However, some images can't be fixed because they
  are encoded in some JPG variant that I haven't been able to figure out.
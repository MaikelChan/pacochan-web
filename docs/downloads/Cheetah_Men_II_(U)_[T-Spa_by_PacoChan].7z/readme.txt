                      CHEETAHMEN II EN ESPA�OL

                            POR PACOCHAN

                       maikelchan88@gmail.com

                   http://pacochan.tales-tra.com

-----------------------------------------------------------------------

El Cheetahmen II es un juego de NES sin licencia hecho por Active Enterprises,
la panda de genios que hicieron el Action 52, otro juego viene a ser una mierda.
Pero es tan malo y hay tanta historia detr�s de estos juegos que incluso tiene
su encanto y alguna comunidad de "fans" anda por ah�.

Adem�s, son juegos tan raros, sobretodo el Cheetahmen II (ya que realmente no
lleg� a salir al mercado, se encontraron unos pocos miles de copias en un almac�n
cuando la empresa ya dej� de existir), que se han llegado a subastar copias por
m�s de 1000$.

Pues s�, he decidido hacer una traducci�n sobre la versi�n "bugfixeada" que se
puede encontrar en mi misma p�gina, junto con alguna mejora m�s como el cambio
de los colores del texto para hacerlo m�s legible. Ahora se puede disfrutar del
juego del principio a fin sin bugs que lo hacen inacabable, y encima en espa�ol.

De paso, est� mucho mejor redactado porque el texto original era una mierda y
lleno de erratas. Sin m�s dilaci�n, aqu� dejo unas capturas y el parche en
formato IPS.